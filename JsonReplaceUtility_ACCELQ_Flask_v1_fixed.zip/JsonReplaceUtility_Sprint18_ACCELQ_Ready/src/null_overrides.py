import re
from .models import Replacement
from .exceptions import MappingError


_TOKEN_RE = re.compile(r"\.([A-Za-z0-9_]+)|\[(\d+)\]")


def _parse_path(path):
    if not isinstance(path, str) or not path.startswith("$"):
        raise MappingError(f"Invalid force-null path: {path!r}")
    tokens = []
    position = 1
    for match in _TOKEN_RE.finditer(path, 1):
        if match.start() != position:
            raise MappingError(f"Invalid force-null path syntax: {path!r}")
        tokens.append(match.group(1) if match.group(1) is not None else int(match.group(2)))
        position = match.end()
    if position != len(path) or not tokens:
        raise MappingError(f"Invalid force-null path syntax: {path!r}")
    return tokens


def apply_force_nulls(data, paths, engine=None, row_number=0):
    """Set configured JSON paths to null after Excel mappings are applied."""
    for path in paths or []:
        tokens = _parse_path(path)
        node = data
        try:
            for token in tokens[:-1]:
                node = node[token]
            final_token = tokens[-1]
            old_value = node[final_token]
        except (KeyError, IndexError, TypeError) as exc:
            raise MappingError(
                f"Configured force-null path not found in JSON: {path}"
            ) from exc

        if old_value is not None:
            node[final_token] = None
            if engine is not None:
                engine.replacements.append(
                    Replacement(
                        path=path,
                        key=str(final_token),
                        old_value=old_value,
                        new_value=None,
                        excel_column="<forced-null>",
                        rule="force_null",
                        row_number=row_number,
                    )
                )
                engine.stats.replacements += 1
    return data
